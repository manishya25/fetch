<?php
include('inc.php');
$sql="select * from employee";
$result = mysqli_query($conn, $sql);
?>
<table border="1">
<tr>
	<th>idno</th>
	<th>name</th>
	<th>password</th>
	<th>email</th>
	<th>number</th>
	<th>gender</th>
	<th>address</th>
	
	<th>usrname</th>
</tr>

<?php
while ($row=mysqli_fetch_assoc($result))
 {
	$id = $row['id'];
	$name= $row['name'];
	$password= $row['password'];
	$email= $row['Email'];
	$number= $row['mbnumber'];
	$gender= $row['gender'];
	$address= $row['address'];
	$username= $row['username'];

?>
<tr>
	
		 <td><?php echo $id; ?></td>
		 <td><?php echo $name; ?></td>
		 <td><?php echo $password; ?></td>
		 <td><?php echo $email; ?></td>
		 <td><?php echo $number; ?></td>
		 <td><?php echo $gender; ?></td>
		 <td><?php echo $address; ?></td>
		 <td><?php echo $username; ?></td>
	
</tr>
<?php  } ?>
</table>


<?php
    
mysqli_close($conn);
?> 