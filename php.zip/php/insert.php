<?php
include('inc.php');

$a=$_POST['name'];
$b=$_POST['Password'];
$c=$_POST['email'];
$d=$_POST['mbnumber'];
$e=$_POST['gender'];
$f=$_POST['address'];

$g=$_POST['username'];

 


//global $conn;
 

 $sql= "INSERT INTO `employee` (`name`, `password`, `Email`, `mbnumber`, `gender`, `address`, `username`) VALUES ('$a','$b','$c','$d','$e','$f','$g')";
 //echo $sql;die;
mysqli_query($conn,$sql);
echo "registration succesfully";


 

?>

