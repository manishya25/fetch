<!DOCTYPE html>
<html>
<head>
	<title>my form is</title>
</head>
<body>
<h1 align="center">Registration Form</h1>

<form method="post" action="insert.php">
         <table align="center">
            <tr>
               <td>Name:</td> 
               <td><input type = "text" name = "name"></td>
            </tr>

            <tr>
               <td>Password:</td> 
               <td><input type = "Password" name = "Password"></td>
            </tr>
            
            <tr>
               <td>E-mail:</td>
               <td><input type = "text" name = "email"></td>
            </tr>

             <tr>
               <td>MB Number:</td>
               <td><input type = "number" name = "mbnumber"></td>
            </tr>
            
            <tr>
               <td>Gender:</td>
               <td>
                  <input type = "radio" name = "gender" value = "female">Female
                  <input type = "radio" name = "gender" value = "male">Male
               </td>
            </tr>

            <tr>
               <td> Address:</td>
               <td><textarea name = "address" rows = "5" cols = "40"></textarea></td>
            </tr>

             <tr>
               <td>UserName:</td> 
               <td><input type = "text" name = "username"></td>
            </tr>
            
            <tr>
               <td>
                  <input type="submit" name="submit" value = "Register"> 
               </td>
            </tr>
         </table>
      </form>

</body>
</html>